const express = require("express");
const router = express.Router();
const getProperties = require("../controller/getProperty_controller");

router.get("/getproperties", getProperties);

module.exports = router;
