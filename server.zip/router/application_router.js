const express = require("express")
const router = express.Router();
const ApplicationForm = require("../controller/application_controller")

router.route("/apply").post(ApplicationForm);

module.exports = router